import React from 'react'

function Footer() {
  return (
    <div className='justify-center bg-black text-white items-center w-full py-5 '>footer</div>
  )
}

export default Footer