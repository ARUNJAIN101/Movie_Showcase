import React from 'react'

function Loading_Spinner() {
  return (
    <div>Loading_Spinner</div>
  )
}

export default Loading_Spinner