import React from 'react'

function ContactUs() {
  return (
    <div className='min-h-screen w-full flex bg-[black]/[0.8] text-white flex-col gap-5 justify-center items-center text-3xl font-bold'>
        <p>
          THIS GOD-LEVEL WEB IS CREATED BY -:
        </p>
        <h1>EMPEROR</h1>
        <p>CONTACT US -: 011 2553 2553 </p>
    </div>
  )
}

export default ContactUs