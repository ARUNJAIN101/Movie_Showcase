import React from 'react'
import Header from '../components/Header'
import Homesection from '../components/Homesection'

function Home_page() {
  return (
   <div>
    <Header></Header>
    <Homesection></Homesection>
   </div>
  )
}

export default Home_page